# angular-send-dynamic-data-to-svs

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-send-dynamic-data-to-svs)